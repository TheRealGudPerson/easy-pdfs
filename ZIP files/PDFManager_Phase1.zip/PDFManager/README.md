# PDF Manager

Cross-platform PDF organizer built with Python, PySide6, and PyMuPDF.

## Phase 1

- Modern desktop GUI
- Windows/macOS compatible architecture
- Add multiple PDFs
- Drag-and-drop PDF files
- Document sidebar
- Light/dark mode
- Native file picker
- Basic keyboard shortcuts

## Run

```bash
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

Phase 2 will add PDF page loading, thumbnails, selection, and the page workspace.
